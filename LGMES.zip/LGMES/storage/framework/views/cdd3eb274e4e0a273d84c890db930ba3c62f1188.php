
<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('components.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="blog-posts grid-system">
      <div class="container">
        <?php $__currentLoopData = $lgus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lgu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
                <div class="col-lg-12">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="https://drive.google.com/uc?export=view&id=<?php echo e($lgu->link_token); ?>" alt="" height="350" width="300">
                    </div>
                    <div class="down-content">
                      <!-- <span>Lifestyle</span> -->
                     <h4><?php echo e($lgu->citymun); ?></h4>
                      <ul class="post-info">
                        <li><?php echo e($lgu->capital); ?></a></li>
                        <li><?php echo e($lgu->population); ?></li>
                        <li><?php echo e($lgu->zip_code); ?></li>
                      </ul>
                      <p><?php echo e($lgu->lgu_description); ?></p>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-6">
                          </div>
                          <div class="col-6">
                            <ul class="post-share">
                              <li><i class="fa fa-share-alt"></i></li>
                              <li><a href="#">Facebook</a>,</li>
                              <li><a href="#"> Twitter</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
               
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                <div class="col-lg-12">
                  <div class="sidebar-item search">
                    <form id="search_form" name="gs" method="GET" action="#">
                      <input type="text" name="q" class="searchText" placeholder="type to search..." autocomplete="on">
                    </form>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="content">
                      <ul>
                        <li><a href="#">
                          <h5>Reports</h5>
                        </a></li>
                        <li><a href="#">
                          <h5>Barangays</h5>
                        </a></li>
                        <li><a href="#">
                          <h5>Contacts</h5>
                        </a></li>
                        <li><a href="#">
                          <h5>List of Elected Officials</h5>
                        </a></li>
                      </ul>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LGMES\resources\views/main/cm.blade.php ENDPATH**/ ?>