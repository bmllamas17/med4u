 <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="/"><h2><img src="<?php echo e(asset('dilg.png')); ?>" alt="" width="70"></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">

              <li class="nav-item">
                <a class="nav-link" href="/">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                  <a class="nav-link" href="/about-us">Manage LGUs</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/about-us">Reports</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/about-us"><?php echo e(auth()->user()->name); ?></a>
                </li>
                <li class="nav-item">
                  <form action="/logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-secondary">Logout</button>
                  </form>
                </li>
              <?php else: ?>
                <li class="nav-item">
                  <a class="nav-link" href="/about-us">About Us</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/lgu-reports">LGU Monitoring</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/contact-us">Contact Us</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/login">Login</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/register">Sign up</a>
                </li>
          
              <?php endif; ?>


            </ul>
          </div>
        </div>
      </nav>
    </header><?php /**PATH C:\xampp\htdocs\LGMES\resources\views/components/navbar.blade.php ENDPATH**/ ?>