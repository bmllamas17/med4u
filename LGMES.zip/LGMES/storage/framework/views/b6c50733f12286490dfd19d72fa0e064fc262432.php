


<?php $__env->startSection('admin_header'); ?>
 <!-- Page-header start -->
  <div class="page-header">
      <div class="page-block">
          <div class="row align-items-center">
              <div class="col-md-8">
                  <div class="page-header-title">
                      <h5 class="m-b-10">View Report</h5>
                      <p class="m-b-0">Welcome to DILG Local Government Monitoring and Evaluation System</p>
                  </div>
              </div>
              <div class="col-md-4">
                  <ul class="breadcrumb-title">
                      <li class="breadcrumb-item">
                          <a href="/"> <i class="fa fa-home"></i> </a>
                      </li>
                      <li class="breadcrumb-item"><a href="#">View Report</a>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>

  <div class="page-wrapper">
    <!-- Page-body start -->
    <div class="page-body">
        <form action="/insert_report" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
           
                <div class="col-xl-12 col-md-12">
                    <div class="card table-card">
                        <div class="card-header">
                            <div class="card-header-left">
                               <a href="/reports" class="btn btn-inverse"><i class="ti-angle-left"></i> Back</a>
                            </div>
                            <!-- <div class="card-header-right">
                               <button class="btn btn-success" type="submit">Upload <i class="ti-check text-white"></i></button>
                            </div> -->
                        </div>
                        <div class="card-body">
                            <div class="row">
                              <div class="col-md-5">
                                <label for="">Title</label>
                                <input type="text" class="form-control" name="title" value="<?php echo e($report->title); ?>" readonly="">
                              </div>
                              <div class="col-md-7">
                                <label for="">Report <i class="text-danger">(.xls, .xlsx)</i></label>
                                <input type="text" class="form-control" name="title" value="<?php echo e($report->report_file); ?>" readonly="">
                               
                              </div>
                            </div>
                            <div class="row mt-5">
                              <div class="col-md-5">
                                <label for="">Description</label>
                                <textarea name="description" id="" cols="30" rows="7" class="form-control" readonly=""><?php echo e($report->description); ?></textarea>
                              </div>
                              <div class="col-md-4">
                                <label for="">Frequency</label>
                                <input type="text" readonly="" class="form-control" value="<?php if($report->frequency == 1): ?>Monthly <?php elseif($report->frequency == 2): ?>Quarterly <?php elseif($report->frequency == 3): ?>Semi Yearly <?php else: ?> Annually <?php endif; ?>
                                ">
                              </div>
                              <div class="col-md-3">
                                <label for="">Year</label>
                                <input type="text" class="form-control" name="title" value="<?php echo e($report->report_year); ?>" readonly="">
                              </div>
                            </div>

                            <div class="row mt-5">
                              <div class="col-md-12">
                     
                                <table class="table table-hover table-bordered mt-2" id="table_header">
                                  <thead>
                                    <th>Province</th>
                                    <th>City/Municipality</th>
                                    <?php if($headers['report_header_1'] != ''): ?>
                                      <th><?php echo e($headers['report_header_1']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_2'] != ''): ?>
                                      <th><?php echo e($headers['report_header_2']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_3'] != ''): ?>
                                      <th><?php echo e($headers['report_header_3']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_4'] != ''): ?>
                                      <th><?php echo e($headers['report_header_4']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_5'] != ''): ?>
                                      <th><?php echo e($headers['report_header_5']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_6'] != ''): ?>
                                      <th><?php echo e($headers['report_header_6']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_7'] != ''): ?>
                                      <th><?php echo e($headers['report_header_7']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_8'] != ''): ?>
                                      <th><?php echo e($headers['report_header_8']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_9'] != ''): ?>
                                      <th><?php echo e($headers['report_header_9']); ?></th>
                                    <?php endif; ?>
                                    <?php if($headers['report_header_10'] != ''): ?>
                                      <th><?php echo e($headers['report_header_10']); ?></th>
                                    <?php endif; ?>
                                  </thead>
                                  <tbody>

                                    <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td><?php echo e($entry->lgu); ?></td>
                                        <td><?php echo e($entry['province']); ?></td>
                                        <?php if($entry['input_1'] != ''): ?>
                                          <td><?php echo e($entry['input_1']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_2'] != ''): ?>
                                          <td><?php echo e($entry['input_2']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_3'] != ''): ?>
                                          <td><?php echo e($entry['input_3']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_4'] != ''): ?>
                                          <td><?php echo e($entry['input_4']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_5'] != ''): ?>
                                          <td><?php echo e($entry['input_5']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_6'] != ''): ?>
                                          <td><?php echo e($entry['input_6']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_7'] != ''): ?>
                                          <td><?php echo e($entry['input_7']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_8'] != ''): ?>
                                          <td><?php echo e($entry['input_8']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_9'] != ''): ?>
                                          <td><?php echo e($entry['input_9']); ?></td>
                                        <?php endif; ?>
                                        <?php if($entry['input_10'] != ''): ?>
                                          <td><?php echo e($entry['input_10']); ?></td>
                                        <?php endif; ?>
                                      </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                                </table>
                              </div>
                            </div>


                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
    <!-- Page-body end -->
  </div>

<?php $__env->stopSection(); ?>

<script>
  var th_val = 1;

  function add_th()
  {
    $("#table_header>thead>tr").append('<th><input type="text" class="form-control" name="report_header_'+th_val+'" required=""></th>');

    th_val++;
  }

</script>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LGMES\resources\views/admin/view_report.blade.php ENDPATH**/ ?>