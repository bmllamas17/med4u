
<?php $__env->startSection('content'); ?>
<?php $province_name = [ "10" => "Batangas", "34" => "Laguna", "21" => "Cavite", "58" => "Rizal", "56" => "Quezon" ]; ?> 
  <?php echo $__env->make('components.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="blog-posts grid-system">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="all-blog-posts">
            <div class="row">
              <?php $__currentLoopData = $lgus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lgu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-4">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="https://drive.google.com/uc?export=view&id=<?php echo e($lgu->link_token); ?>" alt="" height="260">
                    </div>
                    <div class="down-content">
                      <center><a href="/lgu-profile/cm/<?php echo e($lgu->id); ?>"><h4><?php echo e($lgu->citymun); ?></h4></a></center>
                      <ul class="post-info">
                        <center>
                          <li><a href="#"><?php echo e($province_name[$lgu->province]); ?></a></li>
                          <li><a href="#"><?php echo e($lgu->capital); ?></a></li>
                          <li><a href="#"><?php echo e($lgu->population); ?></a></li>
                          <li><a href="#"><?php echo e($lgu->zip_code); ?></a></li>
                        </center>
                      </ul>
                      <!-- <p><?php echo e($lgu->lgu_description); ?></p> -->
                    </div>
                  </div>
                </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!--               <div class="col-lg-12">
                <ul class="page-numbers">
                  <li><a href="#">1</a></li>
                  <li class="active"><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
                </ul>
              </div> -->

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LGMES\resources\views/main/cm-list.blade.php ENDPATH**/ ?>