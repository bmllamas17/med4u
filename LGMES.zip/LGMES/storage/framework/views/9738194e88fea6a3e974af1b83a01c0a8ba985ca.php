
<?php $__env->startSection('content'); ?>

  <div class="heading-page header-text">
    <section class="page-heading">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="text-content">
	        	<div class="row">
		        	<div class="col-md-4"></div>
		        	<div class="col-md-4">
			         	<div style="border: 1px solid gray; padding: 22px; border-radius: 5px; background-color: #fff;">
			         		<form method="POST" action="/users/authenticate">
        					<?php echo csrf_field(); ?>
			         			<center>
			         				<h3>Admin Login</h3>
			         			</center>
			         			<label for="" class="mt-3">Username</label>
			         			<input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>">
				                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                	<p class="text-danger text-xs mt-1"><?php echo e($message); ?></p>
				                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			         			<label for="" class="mt-3">Password</label>
			         			<input type="password" class="form-control" name="password">
				                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                	<p class="text-danger text-xs mt-1"><?php echo e($message); ?></p>
				                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			         			<center>
			         				<button class="btn btn-primary mt-3">Login</button>
			         			</center>
			         		</form>

			         		<!-- <center><a href="/register" class="mt-2"><i><u>register admin here.</u></i></a></center> -->
			         	</div>	
		        	</div>
		        	<div class="col-md-4"></div>
	        	</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LGMES\resources\views/main/login.blade.php ENDPATH**/ ?>