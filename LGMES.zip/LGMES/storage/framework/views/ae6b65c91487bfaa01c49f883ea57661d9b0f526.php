    
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <ul class="social-icons">
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">Behance</a></li>
            <li><a href="#">Linkedin</a></li>
            <li><a href="#">Dribbble</a></li>
          </ul>
        </div>
        <div class="col-lg-12">
          <div class="copyright-text">
            <p>Copyright 2023 DILG-RICTU</p>
          </div>
        </div>
      </div>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\LGMES\resources\views/components/footer.blade.php ENDPATH**/ ?>