  <!-- Banner Starts Here -->
  <div class="heading-page header-text">
    <section class="page-heading">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="text-content">
              <center>
              <h4>DILG CALABARZON</h4>
              <h2>LOCAL GOVERNMENT MONITORING</h2>
              <h2>AND EVALUATION DIVISION</h2>
              </center>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  
  <!-- Banner Ends Here -->