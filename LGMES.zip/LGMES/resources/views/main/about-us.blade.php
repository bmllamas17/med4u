@extends('index')
@section('content')

  @include('components.banner')

  <section class="blog-posts grid-system">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>
            <center>
              <b>About LGME DASHBOARD</b>
            </center>
          </p>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras varius, augue in tristique pretium, ipsum est finibus lacus, finibus laoreet orci ante nec felis. Etiam vitae metus iaculis mi eleifend porta. Integer non auctor magna. Sed vitae convallis mauris, lacinia ultrices dolor. Vivamus nisi erat, dapibus eu eleifend ut, tincidunt at mi. Praesent fringilla, leo nec volutpat feugiat, velit est imperdiet turpis, a iaculis quam dui quis tellus. Mauris quis condimentum massa, eu tincidunt dui. Maecenas lobortis vel metus nec rutrum. Cras a elit posuere, egestas arcu sed, vestibulum tortor. Nam ornare orci a magna gravida condimentum. Vivamus vitae pulvinar leo, ac vehicula arcu. Suspendisse ut lobortis lorem. Mauris nunc ante, pellentesque non commodo ut, iaculis ut purus. Morbi consequat congue elit vitae volutpat.

            Curabitur vel mattis ligula. Donec elit elit, sollicitudin sit amet maximus in, semper a dolor. Mauris vestibulum porttitor felis, nec gravida ante mattis mattis. Proin rhoncus, erat id gravida porttitor, nisi nisl lacinia risus, ac tempus neque nisi nec justo. Pellentesque pellentesque odio et ex pulvinar, in rhoncus turpis malesuada. Nam vel eros malesuada, dictum risus sodales, consequat urna. Nam rutrum dolor non tortor suscipit, sit amet finibus ipsum facilisis. Suspendisse eu imperdiet justo.
          </p>    
        </div>
      </div>
    </div>
  </section>

@endsection